#
# Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
# or more contributor license agreements. Licensed under the Elastic License 2.0;
# you may not use this file except in compliance with the Elastic License 2.0.
#
"""Google Bigquery source module responsible to fetch documents from Google Bigquery.
"""
import asyncio
import json
from collections import defaultdict
from copy import copy

from aiofiles.os import remove
from aiofiles.tempfile import NamedTemporaryFile
from gcloud.aio.bigquery import bigquery as BigqueryModule
from gcloud.aio.bigquery import dataset as DatasetModule
from gcloud.aio.bigquery import table as TableModule

from connectors.logger import logger
from connectors.source import BaseDataSource

PROJECT = "project"
LIST_DATASETS = "list_datasets"
LIST_TABLES = "list_tables"
GET_TABLE_SCHEMA = "get"
LIST_TABLEDATA = "list_tabledata"
METHODS_INFO = {
    PROJECT: {
        "next_page_token": None,
    },
    LIST_DATASETS: {
        "params": {"all": "True"},
        "next_page_token": "nextPageToken",
    },
    LIST_TABLES: {
        "params": {"pageToken": ""},
        "next_page_token": "nextPageToken",
    },
    GET_TABLE_SCHEMA: {
        "next_page_token": None,
    },
    LIST_TABLEDATA: {
        "params": {"pageToken": ""},
        "next_page_token": "pageToken",
    },
}
CLASS_METHODS = {
    "BIGQUERY_BASE": "BigqueryBase",
    "DATASET": "Dataset",
    "TABLE": "Table",
}
DEFAULT_RETRY_COUNT = 3
DEFAULT_WAIT_MULTIPLIER = 2
REQUEST_TIMEOUT = 60


class GoogleBigQueryDataSource(BaseDataSource):
    """Google Bigquery"""

    def __init__(self, configuration):
        """Setup connection to the Google Bigquery Client.

        Args:
            configuration (DataSourceConfiguration): Object of DataSourceConfiguration class.
        """
        super().__init__(configuration=configuration)
        self.retry_count = self.configuration["retry_count"]
        self.credentials_filename = None
        self.project = None

    @classmethod
    def get_default_configuration(cls):
        """Get the default configuration for Google Bigquery.

        Returns:
            dictionary: Default configuration.
        """
        default_credentials = {
            "type": "service_account",
            "project_id": "dev",
            "private_key_id": "123123",
            "private_key": "-----BEGIN CERTIFICATE----- Certificate -----END CERTIFICATE-----",
            "client_email": "dum@dum.iam.gserviceaccount.com",
            "client_id": "1231231123213",
            "auth_uri": "https://accounts.google.com/o/oauth2/auth",
            "token_uri": "https://oauth2.googleapis.com/token",
            "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
            "client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/sfk/eafini.com",
        }
        return {
            "service_account_credentials": {
                "value": json.dumps(default_credentials),
                "label": "JSON string for Google cloud service account",
                "type": "str",
            },
            "connector_name": {
                "value": "Google Bigquery Connector",
                "label": "Friendly name for the connector",
                "type": "str",
            },
            "retry_count": {
                "value": DEFAULT_RETRY_COUNT,
                "label": "Retry count for failed requests",
                "type": "int",
            },
        }

    async def close(self):
        """Method to remove service temporary file object at the end of the execution"""
        if self.credentials_filename is not None:
            await remove(self.credentials_filename)  # pyright: ignore

    async def _api_call(self, module, klass, method, **kwargs):
        """Method for adding retries whenever exception raised during an api calls

        Args:
            module (gcloud.aio.bigquery): Bigquery package module name through which api call will be made.
            klass (gcloud.aio.bigquery.Klass): Available class name in Bigquery package module which contains request method.
            method (gcloud.aio.bigquery.Klass.method): Request method name available in bigquery class for an api call.
            kwargs (Dictionary): Contains required class and method parameters for an api call.

        Raises:
            exception: An instance of an exception class.

        Yields:
            Dictionary: Response returned by the request method.
        """
        retry_counter = 0
        klass_params, method_params = {}, {}
        for key, value in kwargs.items():
            klass_params.update({key: value}) if key in [
                "dataset_name",
                "table_name",
            ] else method_params.update({key: value})
        while True:
            try:
                klass_object = getattr(module, klass)
                async with klass_object(
                    service_file=self.credentials_filename, **klass_params
                ) as gbq_client:
                    method_object = getattr(gbq_client, method)
                    is_next_page = True
                    next_page_token = METHODS_INFO[method]["next_page_token"]
                    while is_next_page:
                        response = await method_object(**method_params)
                        yield response
                        if method != PROJECT and next_page_token in response:
                            is_next_page = (
                                response[next_page_token]
                                if is_next_page != response[next_page_token]
                                else False
                            )
                            method_params["params"].update({"pageToken": is_next_page})
                        else:
                            break
                    break
            except AttributeError as error:
                logger.error(
                    f"Error occurred while generating the klass/method object for an API call. Error: {error}"
                )
                raise
            except Exception as exception:
                retry_counter += 1
                if retry_counter > self.retry_count:
                    raise exception
                logger.warning(
                    f"Retry count: {retry_counter} out of {self.retry_count}. Exception: {exception}"
                )
                await asyncio.sleep(DEFAULT_WAIT_MULTIPLIER**retry_counter)

    async def _generate_temporary_service_file(self):
        """Validates whether user input is empty or not for configuration fields and generate temporary service credentials file

        Raises:
            Exception: Configured service_account_credentials can't be empty

        """
        if not self.configuration["service_account_credentials"]:
            raise Exception("service_account_credentials can't be empty.")

        async with NamedTemporaryFile(
            suffix=".json", mode="w", delete=False
        ) as service_creds_file:
            await service_creds_file.write(
                self.configuration["service_account_credentials"]
                .strip()
                .encode("unicode_escape")
                .decode()
            )
            self.credentials_filename = service_creds_file.name

    async def ping(self):
        """Verify the connection with Google Bigquery"""
        try:
            logger.info("Generating temporary service credentials file...")
            await self._generate_temporary_service_file()
            self.project = await anext(
                self._api_call(
                    module=BigqueryModule,
                    klass=CLASS_METHODS["BIGQUERY_BASE"],
                    method=PROJECT,
                )
            )
            logger.info("Successfully connected to the Google Bigquery.")
        except Exception:
            logger.exception("Error while connecting to the Google Bigquery.")
            raise

    async def fetch_datasets(self):
        """Fetch the datasets from the Google Bigquery.

        Yields:
            Dictionary: Contains the list of fetched datasets from Google Bigquery.
        """
        async for datasets in self._api_call(
            module=DatasetModule,
            klass=CLASS_METHODS["DATASET"],
            method=LIST_DATASETS,
            timeout=REQUEST_TIMEOUT,
            params=copy(METHODS_INFO[LIST_DATASETS]["params"]),
        ):
            yield datasets.get("datasets", [])

    async def fetch_tables(self, datasets):
        """Fetches tables stored in the datasets from Google Bigquery.

        Args:
            datasets (Dictionary): Contains the list of fetched datasets from Google Bigquery.

        Yields:
            Dictionary: Contains the list of fetched tables from Google Bigquery.
        """
        for dataset in datasets:
            async for tables in self._api_call(
                module=DatasetModule,
                klass=CLASS_METHODS["DATASET"],
                method=LIST_TABLES,
                dataset_name=dataset["datasetReference"]["datasetId"],
                timeout=REQUEST_TIMEOUT,
                params=copy(METHODS_INFO[LIST_TABLES]["params"]),
            ):
                yield tables.get("tables", [])

    async def fetch_table_schema(self, dataset_name, table_name):
        """Fetches schema of a table stored in the dataset from Google Bigquery.

        Args:
            dataset_name (String): Name of a dataset from Google Bigquery.
            table_name (String): Name of a table in the dataset from Google Bigquery.

        Yields:
            Dictionary: Contains schema of a table stored in the dataset from Google Bigquery.
        """
        return await anext(
            self._api_call(
                module=TableModule,
                klass=CLASS_METHODS["TABLE"],
                method=GET_TABLE_SCHEMA,
                dataset_name=dataset_name,
                table_name=table_name,
                timeout=REQUEST_TIMEOUT,
            )
        )

    def recursive_get_fields(self, fields, field_prefix):
        """Recursive method to get fields of a table with a RECORD type

        Args:
            fields (Dictionary): Contains multiple fields with unwanted metadata.
            field_prefix (String): Prefix for column name.

        Returns:
            List : Contains column names of a table.
        """
        table_fields = []
        for field in fields:
            if field["type"] != "RECORD":
                table_fields.append(f"{field_prefix}.{field['name']}")
                continue
            field_name = self.recursive_get_fields(
                fields=field["fields"], field_prefix=f"{field_prefix}.{field['name']}"
            )
            table_fields.extend(field_name)
        return table_fields

    def recursive_get_values(self, values):
        """Recursive method to get values of a row for the fields with a RECORD type or a REPEATED mode

        Args:
            values (Dictionary): Contains multiple values for the fields with a RECORD type.

        Returns:
            List : Contains values of a row in the table.
        """
        row_values = []
        for value in values:
            if not value["v"] or isinstance(value["v"], str):
                row_values.append(value["v"])
                continue
            multiple_values = (
                value["v"] if isinstance(value["v"], list) else value["v"]["f"]
            )
            row_value = self.recursive_get_values(multiple_values)
            row_values.extend(row_value)
        return row_values

    def prepare_row_document(self, table_schema, row_values, dataset_name, table_name):
        """Returns dictionary of row document present in the table.

        Args:
            table_schema (Dictionary): Contains fileds of the table.
            row_values (Dictionary): Contains values of a table row.
            dataset_name (String): Name of the dataset.
            table_name (String): Name of the table.

        Returns:
            row_document (Dictionary): Contains data of a row in the table.
        """
        row_document = {}
        for field_index, row_field in enumerate(table_schema["schema"]["fields"]):
            if row_field["type"] != "RECORD":
                value = (
                    self.recursive_get_values(values=row_values[field_index]["v"])
                    if isinstance(row_values[field_index]["v"], list)
                    else row_values[field_index]["v"]
                )
                row_document.update(
                    {f"{dataset_name}.{table_name}.{row_field['name']}": value}
                )
                continue
            table_fields = self.recursive_get_fields(
                fields=row_field["fields"],
                field_prefix=f"{dataset_name}.{table_name}.{row_field['name']}",
            )
            values = (
                row_values[field_index]["v"]["f"]
                if row_field["mode"] == "NULLABLE"
                else row_values[field_index]["v"]
            )
            field_values = self.recursive_get_values(values=values)
            document = defaultdict(list, {field: [] for field in table_fields})
            chunk_size = len(table_fields)
            while field_values:
                chunk, field_values = (
                    field_values[:chunk_size],
                    field_values[chunk_size:],
                )
                for field, value in zip(table_fields, chunk):
                    document[field].append(value)
            row_document.update(document)
        return row_document

    async def fetch_tables_data(self, tables):
        """Fetches tables data row wise from Google Bigquery.

        Args:
            tables (Dictionary): Contains the list of fetched tables from Google Bigquery.

        Yields:
            Dictionary: Contains data of a row in the table.
        """
        for table in tables:
            dataset_name = table["tableReference"]["datasetId"]
            table_name = table["tableReference"]["tableId"]
            if "type" in table and table["type"] != "TABLE":
                logger.warning(
                    f"Skipping {table_name} from dataset {dataset_name} as it's not a table."
                )
                continue
            table_schema = await self.fetch_table_schema(
                dataset_name=dataset_name, table_name=table_name
            )
            if "schema" in table_schema and "fields" in table_schema["schema"]:
                row_number = 0
                async for table_data in self._api_call(
                    module=TableModule,
                    klass=CLASS_METHODS["TABLE"],
                    method=LIST_TABLEDATA,
                    dataset_name=dataset_name,
                    table_name=table_name,
                    timeout=REQUEST_TIMEOUT,
                    params=copy(METHODS_INFO[LIST_TABLEDATA]["params"]),
                ):
                    if "rows" in table_data:
                        for row in table_data["rows"]:
                            row_document = self.prepare_row_document(
                                table_schema=table_schema,
                                row_values=row["f"],
                                dataset_name=dataset_name,
                                table_name=table_name,
                            )
                            row_number += 1
                            row_document.update(
                                {
                                    "_id": f"{dataset_name}_{table_name}_{row_number}",
                                    "_timestamp": table_schema["lastModifiedTime"],
                                    "dataset": dataset_name,
                                    "table": table_name,
                                }
                            )
                            yield row_document
                    else:
                        logger.warning(
                            f"Skipping table {table_name} from dataset {dataset_name} as there is no data available."
                        )
            else:
                logger.warning(
                    f"Skipping table {table_name} from dataset {dataset_name} as there are no table fields available."
                )

    async def get_docs(self):
        """Executes the logic to fetch datasets, tables and rows in async manner.

        Yields:
            dictionary: Row dictionary containing meta-data of the row.
        """
        async for datasets in self.fetch_datasets():
            async for tables in self.fetch_tables(datasets=datasets):
                async for row in self.fetch_tables_data(tables=tables):
                    yield row, None
