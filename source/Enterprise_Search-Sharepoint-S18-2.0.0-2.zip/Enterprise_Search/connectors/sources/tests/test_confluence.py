#
# Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
# or more contributor license agreements. Licensed under the Elastic License 2.0;
# you may not use this file except in compliance with the Elastic License 2.0.
#
"""Tests the Confluence database source class methods"""
import ssl
from copy import copy
from unittest import mock
from unittest.mock import patch

import pytest
from aiohttp import StreamReader
from freezegun import freeze_time

from connectors.source import DataSourceConfiguration
from connectors.sources.confluence import ConfluenceDataSource
from connectors.sources.tests.support import create_source
from connectors.utils import ssl_context

CONFUENCE = "connectors.sources.confluence.ConfluenceDataSource"
HOST_URL = "http://127.0.0.1:5000"
CONTENT_QUERY = "limit=1&expand=children.attachment,history.lastUpdated,body.storage"
RESPONSE_SPACE = {
    "results": [
        {
            "id": 4554779,
            "name": "DEMO",
            "_links": {
                "webui": "/spaces/DM",
            },
        }
    ],
    "start": 0,
    "limit": 1,
    "size": 1,
    "_links": {},
}

RESPONSE_PAGE = {
    "results": [
        {
            "id": 4779,
            "title": "ES-scrum",
            "type": "page",
            "history": {"lastUpdated": {"when": "2023-01-24T04:07:19.672Z"}},
            "children": {"attachment": {"size": 2}},
            "body": {"storage": {"value": "This is a test page"}},
            "space": {"name": "DEMO"},
            "_links": {
                "webui": "/spaces/~1234abc/pages/4779/ES-scrum",
            },
        }
    ],
    "start": 0,
    "limit": 1,
    "size": 1,
    "_links": {},
}

EXPECTED_PAGE = {
    "_id": 4779,
    "type": "page",
    "_timestamp": "2023-01-24T04:07:19.672Z",
    "title": "ES-scrum",
    "body": "This is a test page",
    "space": "DEMO",
    "url": f"{HOST_URL}/spaces/~1234abc/pages/4779/ES-scrum",
}

EXPECTED_SPACE = {
    "_id": 4554779,
    "type": "Space",
    "title": "DEMO",
    "_timestamp": "2023-01-24T04:07:19+00:00",
    "url": f"{HOST_URL}/spaces/DM",
}

RESPONSE_ATTACHMENT = {
    "results": [
        {
            "id": "att3637249",
            "title": "demo.py",
            "type": "attachment",
            "version": {"when": "2023-01-03T09:24:50.633Z"},
            "extensions": {"fileSize": 230},
            "_links": {
                "download": "/download/attachments/1113/demo.py?version=1&modificationDate=1672737890633&cacheVersion=1&api=v2",
                "webui": "/pages/viewpageattachments.action?pageId=1113&preview=demo.py",
            },
        }
    ],
    "start": 0,
    "limit": 1,
    "size": 1,
    "_links": {},
}

EXPECTED_ATTACHMENT = {
    "_id": "att3637249",
    "type": "attachment",
    "_timestamp": "2023-01-03T09:24:50.633Z",
    "title": "demo.py",
    "size": 230,
    "space": "DEMO",
    "page": "ES-scrum",
    "url": f"{HOST_URL}/pages/viewpageattachments.action?pageId=1113&preview=demo.py",
}

RESPONSE_CONTENT = "# This is the dummy file"

EXPECTED_CONTENT = {
    "_id": "att3637249",
    "_timestamp": "2023-01-03T09:24:50.633Z",
    "_attachment": "IyBUaGlzIGlzIHRoZSBkdW1teSBmaWxl",
}

EXPECTED_BLOG = {
    "_id": 4779,
    "type": "blogpost",
    "_timestamp": "2023-01-24T04:07:19.672Z",
    "title": "demo-blog",
    "body": "This is a test blog",
    "space": "DEMO",
    "url": f"{HOST_URL}/spaces/~1234abc/blogposts/4779/demo-blog",
}

EXPECTED_BLOG_ATTACHMENT = {
    "_id": "att3637249",
    "type": "attachment",
    "_timestamp": "2023-01-03T09:24:50.633Z",
    "title": "demo.py",
    "size": 230,
    "space": "DEMO",
    "blog": "demo-blog",
    "url": f"{HOST_URL}/pages/viewpageattachments.action?pageId=1113&preview=demo.py",
}


class MockJsonResponse:
    """Class to mock json response of aiohttp session.get method"""

    def __init__(self, json, status):
        """Setup a json response"""
        self._json = json
        self.status = status

    async def json(self):
        """Method to return a JSON content of the result"""
        return self._json

    async def __aexit__(self, exc_type, exc, tb):
        """Closes an async with block"""
        pass

    async def __aenter__(self):
        """Enters an async with block"""
        return self


class MockObjectResponse:
    """Class to mock object response of aiohttp session.get method"""

    def __init__(self):
        """Setup a streamReader object"""
        self.content = StreamReader

    async def __aexit__(self, exc_type, exc, tb):
        """Closes an async with block"""
        pass

    async def __aenter__(self):
        """Enters an async with block"""
        return self


class AsyncIter:
    """This Class is use to return async generator"""

    def __init__(self, *args):
        """Setup list of dictionary"""

        self.result = args

    async def __aiter__(self):
        """This Method is used to return async generator"""
        if len(self.result) == 1:
            yield self.result[0]
        else:
            yield (*self.result,)


@pytest.mark.asyncio
async def test_validate_configuration_with_invalid_concurrent_downloads():
    """Test validate configuration method of BaseDataSource class with invalid concurrent downloads"""

    # Setup
    source = create_source(ConfluenceDataSource)
    source.concurrent_downloads = 1000

    # Execute
    with pytest.raises(
        Exception, match="Configured concurrent downloads can't be set more than *"
    ):
        await source.validate_config()


def test_tweak_bulk_options():
    """Test tweak_bulk_options method of BaseDataSource class"""

    # Setup
    source = create_source(ConfluenceDataSource)
    options = {"concurrent_downloads": 10}

    # Execute
    source.tweak_bulk_options(options)


@pytest.mark.asyncio
async def test_close_with_client_session(patch_logger):
    # Setup
    source = create_source(ConfluenceDataSource)
    source._generate_session()

    # Execute
    await source.close()

    # Assert
    assert source.session is None


@pytest.mark.asyncio
async def test_close_without_client_session(patch_logger):
    # Setup
    source = create_source(ConfluenceDataSource)

    # Execute
    await source.close()

    # Assert
    assert source.session is None


class MockSSL:
    """This class contains methods which returns dummy ssl context"""

    def load_verify_locations(self, cadata):
        """This method verify locations"""
        pass


@pytest.mark.asyncio
async def test_configuration():
    """Tests the get_default_configurations method of the Confluence source class."""
    # Setup
    klass = ConfluenceDataSource

    # Execute
    config = DataSourceConfiguration(config=klass.get_default_configuration())

    # Assert
    assert config["host_url"] == HOST_URL


@pytest.mark.asyncio
async def test_validate_configuration_for_host_url(patch_logger):
    """This function test _validate_configuration when host_url is invalid"""
    # Setup
    source = create_source(ConfluenceDataSource)
    source.configuration.set_field(name="host_url", value="")

    # Execute
    with pytest.raises(Exception):
        await source.validate_config()


@pytest.mark.asyncio
@patch("aiohttp.ClientSession.get")
async def test_ping_with_ssl(mock_get, patch_logger):
    """Test ping method of ConfluenceDataSource class with SSL"""

    # Execute
    mock_get.return_value.__aenter__.return_value.status = 200
    source = create_source(ConfluenceDataSource)

    source.ssl_enabled = True
    source.certificate = (
        "-----BEGIN CERTIFICATE----- Certificate -----END CERTIFICATE-----"
    )

    # Execute
    with patch.object(ssl, "create_default_context", return_value=MockSSL()):
        source.ssl_ctx = ssl_context(certificate=source.certificate)
        await source.ping()


@pytest.mark.asyncio
@patch("aiohttp.ClientSession.get")
async def test_ping_for_failed_connection_exception(mock_get, patch_logger):
    """Tests the ping functionality when connection can not be established to Confluence."""

    # Setup
    source = create_source(ConfluenceDataSource)

    # Execute
    with patch.object(
        ConfluenceDataSource, "_api_call", side_effect=Exception("Something went wrong")
    ):
        with pytest.raises(Exception):
            await source.ping()


def test_validate_configuration_for_ssl_enabled(patch_logger):
    """This function tests _validate_configuration when certification is empty and ssl is enabled"""
    # Setup
    source = create_source(ConfluenceDataSource)
    source.ssl_enabled = True

    # Execute
    with pytest.raises(Exception):
        source._validate_configuration()


@freeze_time("2023-01-24T04:07:19")
@pytest.mark.asyncio
async def test_get_spaces():
    """Tests the get spaces method."""

    # Setup
    source = create_source(ConfluenceDataSource)

    async_response = MockJsonResponse(RESPONSE_SPACE, 200)

    # Execute and Assert
    with mock.patch("aiohttp.ClientSession.get", return_value=async_response):
        source._generate_session()
        async for response in source.get_spaces():
            assert response == EXPECTED_SPACE


@pytest.mark.asyncio
async def test_fetch_documents():
    """Tests the fetch documents method."""

    # Setup
    source = create_source(ConfluenceDataSource)
    async_response = MockJsonResponse(RESPONSE_PAGE, 200)

    # Execute and Assert
    with mock.patch("aiohttp.ClientSession.get", return_value=async_response):
        source._generate_session()
        async for response, _ in source.fetch_documents(api_query=""):
            assert response == EXPECTED_PAGE


@pytest.mark.asyncio
async def test_fetch_attachments():
    """Tests the bring attachments method."""

    # Setup
    source = create_source(ConfluenceDataSource)
    async_response = MockJsonResponse(RESPONSE_ATTACHMENT, 200)

    # Execute and Assert
    with mock.patch("aiohttp.ClientSession.get", return_value=async_response):
        source._generate_session()
        async for response, _ in source.fetch_attachments(
            content_id=1113,
            parent_name="ES-scrum",
            parent_space="DEMO",
            parent_type="page",
        ):
            assert response == EXPECTED_ATTACHMENT


@pytest.mark.asyncio
async def test_download_attachment():
    """Tests the download attachments method."""
    # Setup
    source = create_source(ConfluenceDataSource)

    async_response = MockObjectResponse()

    # Execute and Assert
    with mock.patch("aiohttp.ClientSession.get", return_value=async_response):
        source._generate_session()
        with mock.patch(
            "aiohttp.StreamReader.iter_chunked",
            return_value=AsyncIter(bytes(RESPONSE_CONTENT, "utf-8")),
        ):
            response = await source.download_attachment(
                url="download/attachments/1113/demo.py?version=1&modificationDate=1672737890633&cacheVersion=1&api=v2",
                attachment=EXPECTED_ATTACHMENT,
                doit=True,
            )
            assert response == EXPECTED_CONTENT


@pytest.mark.asyncio
async def test_download_attachment_when_filesize_is_large():
    """Tests the download attachments method for file size greater than max limit."""
    # Setup
    source = create_source(ConfluenceDataSource)

    async_response = MockObjectResponse()

    # Execute and Assert

    with mock.patch("aiohttp.ClientSession.get", return_value=async_response):
        source._generate_session()
        with mock.patch(
            "aiohttp.StreamReader.iter_chunked",
            return_value=AsyncIter(bytes(RESPONSE_CONTENT, "utf-8")),
        ):
            attachment = copy(EXPECTED_ATTACHMENT)
            attachment["size"] = 23000000

            response = await source.download_attachment(
                url="download/attachments/1113/demo.py?version=1&modificationDate=1672737890633&cacheVersion=1&api=v2",
                attachment=attachment,
                doit=True,
            )
            assert response is None


@pytest.mark.asyncio
async def test_download_attachment_for_unsupported_filetype():
    """Tests the download attachments method for file type is not supported"""
    # Setup
    source = create_source(ConfluenceDataSource)

    async_response = MockObjectResponse()

    with mock.patch("aiohttp.ClientSession.get", return_value=async_response):
        source._generate_session()

        with mock.patch(
            "aiohttp.StreamReader.iter_chunked",
            return_value=AsyncIter(bytes(RESPONSE_CONTENT, "utf-8")),
        ):
            attachment = copy(EXPECTED_ATTACHMENT)

            attachment["title"] = "batch.mysy"

            response = await source.download_attachment(
                url="download/attachments/1113/demo.py?version=1&modificationDate=1672737890633&cacheVersion=1&api=v2",
                attachment=attachment,
                doit=True,
            )
            assert response is None


@pytest.mark.asyncio
@mock.patch(f"{CONFUENCE}.get_spaces", return_value=AsyncIter(EXPECTED_SPACE))
@mock.patch(
    f"{CONFUENCE}.fetch_documents",
    side_effect=[(AsyncIter(EXPECTED_PAGE, 1)), (AsyncIter(EXPECTED_BLOG, 1))],
)
@mock.patch(
    f"{CONFUENCE}.fetch_attachments",
    side_effect=[
        (AsyncIter(EXPECTED_ATTACHMENT, "download-url")),
        (AsyncIter(EXPECTED_BLOG_ATTACHMENT, "download-url")),
    ],
)
@mock.patch(
    f"{CONFUENCE}.download_attachment", return_value=AsyncIter(EXPECTED_CONTENT)
)
async def test_get_docs(spaces_patch, pages_patch, attachment_patch, content_patch):
    """Tests the get_docs method"""

    # Setup
    source = create_source(ConfluenceDataSource)
    expected_responses = [
        EXPECTED_SPACE,
        EXPECTED_PAGE,
        EXPECTED_BLOG,
        EXPECTED_ATTACHMENT,
        EXPECTED_BLOG_ATTACHMENT,
    ]

    # Execute
    documents = []
    async for item, _ in source.get_docs():
        documents.append(item)

    # Assert
    assert documents == expected_responses
