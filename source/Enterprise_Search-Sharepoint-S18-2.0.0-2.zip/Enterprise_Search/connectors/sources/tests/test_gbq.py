#
# Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
# or more contributor license agreements. Licensed under the Elastic License 2.0;
# you may not use this file except in compliance with the Elastic License 2.0.
#
"""Tests the Google Bigquery source class methods.
"""
import asyncio
import json
from unittest import mock

import pytest
from gcloud.aio.bigquery import bigquery as BigqueryModule
from gcloud.aio.bigquery import dataset as DatasetModule
from gcloud.aio.bigquery import table as TableModule
from gcloud.aio.bigquery.bigquery import BigqueryBase

from connectors.source import DataSourceConfiguration
from connectors.sources.gbq import GoogleBigQueryDataSource

SERVICE_ACCOUNT_CREDENTIALS = json.dumps(
    {
        "type": "service_account",
        "project_id": "dummy123",
    }
)
PROJECT = "project"
LIST_DATASETS = "list_datasets"
LIST_TABLES = "list_tables"
GET_TABLE_SCHEMA = "get"
LIST_TABLEDATA = "list_tabledata"
LIST_DATASETS_RESPONSE = {
    "kind": "bigquery#datasetList",
    "etag": "VLsgudu/LOTnYspgFV25ig==",
    "datasets": [
        {
            "kind": "bigquery#dataset",
            "id": "dummy123:dataset1",
            "datasetReference": {
                "datasetId": "dataset1",
                "projectId": "dummy123",
            },
            "location": "US",
        }
    ],
}
LIST_TABLES_RESPONSE = {
    "kind": "bigquery#tableList",
    "etag": "tUIb1NWyHiQLL9S2vEu04Q==",
    "tables": [
        {
            "kind": "bigquery#table",
            "id": "dummy123:dataset1.table1",
            "tableReference": {
                "projectId": "dummy123",
                "datasetId": "dataset1",
                "tableId": "table1",
            },
            "type": "TABLE",
            "creationTime": "1671193235214",
        }
    ],
}
GET_TABLE_SCHEMA_RESPONSE = {
    "kind": "bigquery#table",
    "etag": "VUcwP+iqgCxz0b1OMq5Ekw==",
    "id": "dummy123:dataset1.table1",
    "selfLink": "https://www.googleapis.com/bigquery/v2/projects/dummy123/datasets/dataset1/tables/table1",
    "tableReference": {
        "projectId": "dummy123",
        "datasetId": "dataset1",
        "tableId": "table1",
    },
    "description": "Testing Dataset",
    "schema": {
        "fields": [
            {"name": "series_id", "type": "STRING", "mode": "REQUIRED"},
            {
                "name": "record",
                "type": "RECORD",
                "mode": "REPEATED",
                "fields": [
                    {
                        "name": "inner_record",
                        "type": "RECORD",
                        "mode": "REPEATED",
                        "fields": [
                            {"name": "name", "type": "STRING", "mode": "NULLABLE"}
                        ],
                    }
                ],
            },
        ]
    },
    "numBytes": "826392",
    "numLongTermBytes": "0",
    "numRows": "8049",
    "creationTime": "1671022060664",
    "lastModifiedTime": "1671022060664",
    "type": "TABLE",
    "location": "US",
    "numTimeTravelPhysicalBytes": "0",
    "numTotalLogicalBytes": "826392",
    "numActiveLogicalBytes": "826392",
    "numLongTermLogicalBytes": "0",
    "numTotalPhysicalBytes": "32725",
    "numActivePhysicalBytes": "32725",
    "numLongTermPhysicalBytes": "0",
}
LIST_TABLEDATA_RESPONSE = {
    "kind": "bigquery#tableDataList",
    "pageToken": "next1",
    "etag": "B7e/Bevyp0TvUKQZTfvTow==",
    "totalRows": "1",
    "rows": [
        {
            "f": [
                {"v": "1"},
                {
                    "v": [
                        {
                            "v": {
                                "f": [
                                    {
                                        "v": {
                                            "f": [
                                                {"v": "hi"},
                                                {"v": {"f": [{"v": "bye"}]}},
                                            ]
                                        }
                                    }
                                ]
                            }
                        }
                    ]
                },
            ]
        }
    ],
}
LIST_TABLEDATA_RESPONSE_WITHOUT_PAGETOKEN = {
    "kind": "bigquery#tableDataList",
    "etag": "B7e/Bevyp0TvUKQZTfvTow==",
    "totalRows": "1",
    "rows": [
        {
            "f": [
                {"v": "2"},
                {
                    "v": [
                        {
                            "v": {
                                "f": [
                                    {
                                        "v": {
                                            "f": [
                                                {"v": "hi"},
                                                {"v": {"f": [{"v": "bye"}]}},
                                            ]
                                        }
                                    }
                                ]
                            }
                        }
                    ]
                },
            ]
        }
    ],
}


def side_effect_function(timeout, params):
    """Dynamically changing return values during reading a file in chunks
    Args:
        **kwargs: Maximum bytes allowed to be read at a given time
    """
    if params["pageToken"] == "":
        return LIST_TABLEDATA_RESPONSE
    return LIST_TABLEDATA_RESPONSE_WITHOUT_PAGETOKEN


def get_mocked_source_object():
    """Creates the mocked Google Bigquery object.

    Returns:
        GoogleBigQueryDataSource: Mocked object of the data source class.
    """
    configuration = DataSourceConfiguration(
        {"service_account_credentials": SERVICE_ACCOUNT_CREDENTIALS}
    )
    mocked_gcs_object = GoogleBigQueryDataSource(configuration=configuration)
    return mocked_gcs_object


def test_get_configuration(patch_logger):
    """Tests the get configurations method of the Google Bigquery class."""

    # Setup
    google_bigquery_object = GoogleBigQueryDataSource

    # Execute
    config = DataSourceConfiguration(
        config=google_bigquery_object.get_default_configuration()
    )

    # Assert
    assert type(config["service_account_credentials"]) == str
    assert json.loads(
        config["service_account_credentials"].encode("unicode_escape").decode()
    )


@pytest.mark.asyncio
async def test_empty_configuration(patch_logger):
    """Tests the validity of the configurations passed to the Google Bigquery source class."""

    # Setup
    configuration = DataSourceConfiguration({"service_account_credentials": ""})
    mocked_gbq_object = GoogleBigQueryDataSource(configuration=configuration)

    # Execute
    with pytest.raises(Exception, match="service_account_credentials can't be empty."):
        await mocked_gbq_object._generate_temporary_service_file()

    await mocked_gbq_object.close()


@pytest.mark.asyncio
async def test_ping_for_successful_connection(patch_logger):
    """Tests the ping functionality for ensuring connection to Google Bigquery."""

    # Setup
    expected_response = "dummy123"
    mocked_gbq_object = get_mocked_source_object()
    api_response = asyncio.Future()
    api_response.set_result(expected_response)

    # Execute
    with mock.patch.object(BigqueryBase, "project", return_value=api_response):
        await mocked_gbq_object.ping()

    await mocked_gbq_object.close()


@pytest.mark.asyncio
async def test_ping_for_failed_connection(patch_logger):
    """Tests the ping functionality when connection can not be established to Google Bigquery."""

    # Setup
    configuration = DataSourceConfiguration(
        {"service_account_credentials": '{"project_id": "dummy123"}', "retry_count": 1}
    )
    mocked_gbq_object = GoogleBigQueryDataSource(configuration=configuration)
    mocked_gbq_object.retry_count = 0

    # Execute
    with mock.patch.object(
        BigqueryBase, "project", side_effect=Exception("Something went wrong")
    ):
        with pytest.raises(Exception):
            await mocked_gbq_object.ping()


@pytest.mark.asyncio
async def test_ping_while_attribute_error(patch_logger):
    """Tests the ping functionality while Attribute Error."""

    # Setup
    mocked_gbq_object = get_mocked_source_object()
    await mocked_gbq_object._generate_temporary_service_file()

    # Execute
    with pytest.raises(
        AttributeError,
        match="module 'gcloud.aio.bigquery.bigquery' has no attribute 'dummy_BigqueryBase'",
    ):
        await anext(
            mocked_gbq_object._api_call(
                module=BigqueryModule, klass="dummy_BigqueryBase", method=PROJECT
            )
        )

    await mocked_gbq_object.close()


@pytest.mark.asyncio
async def test_get_docs(patch_logger):
    """Tests the module responsible to fetch and yield table data documents from Google BigQuery."""

    # Setup
    mocked_gbq_object = get_mocked_source_object()
    await mocked_gbq_object._generate_temporary_service_file()
    expected_table_document = [
        {
            "dataset1.table1.series_id": "1",
            "dataset1.table1.record.inner_record.name": ["hi", "bye"],
            "_id": "dataset1_table1_1",
            "_timestamp": "1671022060664",
            "dataset": "dataset1",
            "table": "table1",
        },
        {
            "dataset1.table1.series_id": "2",
            "dataset1.table1.record.inner_record.name": ["hi", "bye"],
            "_id": "dataset1_table1_2",
            "_timestamp": "1671022060664",
            "dataset": "dataset1",
            "table": "table1",
        },
    ]

    # Execute and Assert
    with (
        mock.patch.object(
            DatasetModule.Dataset, LIST_DATASETS, return_value=LIST_DATASETS_RESPONSE
        ),
        mock.patch.object(
            DatasetModule.Dataset, LIST_TABLES, return_value=LIST_TABLES_RESPONSE
        ),
        mock.patch.object(
            TableModule.Table, GET_TABLE_SCHEMA, return_value=GET_TABLE_SCHEMA_RESPONSE
        ),
        mock.patch.object(
            TableModule.Table, LIST_TABLEDATA, side_effect=side_effect_function
        ),
    ):
        async for table_document in mocked_gbq_object.get_docs():
            assert table_document[0] in expected_table_document

    await mocked_gbq_object.close()


@pytest.mark.asyncio
async def test_fetch_tables_data_when_type_is_not_table(patch_logger):
    """Tests the fetch tables data when type is not table."""

    # Setup
    mocked_gbq_object = get_mocked_source_object()
    await mocked_gbq_object._generate_temporary_service_file()
    tables_with_invalid_type = [
        {
            "kind": "bigquery#table",
            "id": "dummy123:dataset1.view1",
            "tableReference": {
                "projectId": "dummy123",
                "datasetId": "dataset1",
                "tableId": "view1",
            },
            "type": "VIEW",
            "creationTime": "1671193235214",
        }
    ]

    # Execute
    async for _ in mocked_gbq_object.fetch_tables_data(tables=tables_with_invalid_type):
        print("Method is called successfully....")

    await mocked_gbq_object.close()


@pytest.mark.asyncio
async def test_fetch_tables_data_when_field_is_empty(patch_logger):
    """Tests fetch tables data when schema is empty."""

    # Setup
    mocked_gbq_object = get_mocked_source_object()
    await mocked_gbq_object._generate_temporary_service_file()
    empty_field_schema = {
        "kind": "bigquery#table",
        "etag": "VUcwP+iqgCxz0b1OMq5Ekw==",
        "id": "dummy123:dataset1.table1",
        "selfLink": "https://www.googleapis.com/bigquery/v2/projects/dummy123/datasets/dataset1/tables/table1",
        "tableReference": {
            "projectId": "dummy123",
            "datasetId": "dataset1",
            "tableId": "table1",
        },
        "description": "Testing Dataset",
        "schema": {},
    }
    api_response = asyncio.Future()
    api_response.set_result(empty_field_schema)
    mocked_gbq_object.fetch_table_schema = mock.MagicMock(return_value=api_response)

    # Execute
    async for _ in mocked_gbq_object.fetch_tables_data(
        tables=LIST_TABLES_RESPONSE["tables"]
    ):
        print("Method is called successfully....")

    await mocked_gbq_object.close()


@pytest.mark.asyncio
async def test_fetch_tables_data_when_no_data_available(patch_logger):
    """Tests fetch tables when data is not available."""

    # Setup
    mocked_gbq_object = get_mocked_source_object()
    await mocked_gbq_object._generate_temporary_service_file()
    mocked_response = {
        "kind": "bigquery#table",
        "etag": "VUcwP+iqgCxz0b1OMq5Ekw==",
        "id": "dummy123:dataset1.table1",
        "selfLink": "https://www.googleapis.com/bigquery/v2/projects/dummy123/datasets/dataset1/tables/table1",
        "tableReference": {
            "projectId": "dummy123",
            "datasetId": "dataset1",
            "tableId": "table1",
        },
        "description": "Testing Dataset",
        "schema": {
            "fields": [{"name": "series_id", "type": "STRING", "mode": "REQUIRED"}]
        },
    }
    api_response = asyncio.Future()
    api_response.set_result(mocked_response)
    mocked_gbq_object.fetch_table_schema = mock.MagicMock(return_value=api_response)
    table_data = {
        "kind": "bigquery#tableDataList",
        "etag": "B7e/Bevyp0TvUKQZTfvTow==",
        "totalRows": "0",
    }
    table_data_response = asyncio.Future()
    table_data_response.set_result(table_data)

    # Execute
    with mock.patch.object(BigqueryBase, "_get_url", return_value=table_data_response):
        async for _ in mocked_gbq_object.fetch_tables_data(
            tables=LIST_TABLES_RESPONSE["tables"]
        ):
            print("Method is called successfully....")

    await mocked_gbq_object.close()


@pytest.mark.asyncio
async def test_get_docs_when_no_datasets_present(patch_logger):
    """Tests get docs when no datasets are present."""

    # Setup
    mocked_gbq_object = get_mocked_source_object()
    await mocked_gbq_object._generate_temporary_service_file()
    project_with_zero_datasets = {
        "kind": "bigquery#datasetList",
        "etag": "VLsgudu/LOTnYspgFV25ig==",
        "totalItems": 0,
    }

    # Execute and Assert
    with mock.patch.object(
        BigqueryBase,
        "_get_url",
        return_value=project_with_zero_datasets,
    ):
        async for table_document in mocked_gbq_object.get_docs():
            assert table_document[0] is None

    await mocked_gbq_object.close()
