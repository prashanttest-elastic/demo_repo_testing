# How to run the service in docker

Make sure you have the latest `docker` command, then build the image:

    make docker-build


To use it, tweak your [configuration file](./CONFIG.md) and run:

    make docker-run

