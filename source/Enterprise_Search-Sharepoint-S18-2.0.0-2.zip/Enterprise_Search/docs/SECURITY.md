# Security Policy

Thanks for your interest in the security of our products. Our security policy can be found at [https://www.elastic.co/community/security](https://www.elastic.co/community/security).

## Reporting a Vulnerability
Please send security vulnerability reports to security@elastic.co.
